# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    # LatestB: Reconfigured to pass in "user" and "pass" instead of it being hard-coded
    def __init__(self, USER, PASS): 
        # PriorA: Initializing the MongoClient. This helps to access the MongoDB 
        # PriorA: databases and collections. This is hard-wired to use the aac 
        # PriorA: database, the animals collection, and the aac user. 
        # 
        # PriorA: You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}') 
        self.database = self.client[DB] 
        self.collection = self.database[COL] 

    # Create a method to return the next available record number for use in the create method
    def get_next_record_number(self):
        # return next available record number
        last_record = self.collection.find_one(sort = [("record_number", -1)])
        if last_record and "record_number" in last_record:
            return last_record["record_number"] + 1
        else:
            #start numbering at 1
            return 1
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None: 
            #insert record number automatically
            if "record_number" not in data:
                data["record_number"] = self.get_next_record_number()
           
            # insert document into collection   
            result = self.collection.insert_one(data)  # data should be dictionary             
            
            # return inserted document ID for verification
            return result.inserted_id
        else: 
            raise Exception("Nothing to save, because data parameter is empty") 

    # Create method to implement the R in CRUD.
    # Method reads documents from the collection based on the query.
    # If no query provided, returns all documents.
    def read(self, query = None):
        # empty query returns all documents
        if query is None:
            query = {}
        
        # returns list of matching query
        return list(self.collection.find(query))
    
    # Create method to implement the U in CRUD.
    # Method finds documents from the collection based on the query.
    # Updates the query value with the new_value.
    def update(self, query, new_value):

        if query is not None:
            result = self.collection.update_many(query, {"$set": new_value})
            return result.modified_count
        return 0


    # Create method to implement the D in CRUD.
    # Method deletes documents from the collection based on the query.
    def delete(self, query):

        if query is not None:
            result = self.collection.delete_many(query)
            return result.deleted_count
        return 0